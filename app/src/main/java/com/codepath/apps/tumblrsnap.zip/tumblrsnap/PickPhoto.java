package com.codepath.apps.tumblrsnap;

import android.app.Fragment;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.provider.MediaStore;
import android.widget.ImageView;
import android.content.Context;
import android.widget.Toast;

import java.io.IOException;

/**
 * Created by alecksjohansson on 4/17/16.
 */
public class PickPhoto extends Fragment{
    public static final int PICK_PHOTO_CODE = 1046;
    public Context context;
    public void onPickPhoto()
    {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        if(intent.resolveActivity(getActivity().getPackageManager()) != null)
        {
            startActivityForResult(intent,PICK_PHOTO_CODE);
        }
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (data != null) {
            Uri photoUri = data.getData();
            // Do something with the photo based on Uri
            try{
            Bitmap selectedImage = MediaStore.Images.Media.getBitmap(getActivity().getContentResolver(), photoUri);
            // Load the selected image into a preview
            ImageView ivPreview = (ImageView) getActivity().findViewById(R.id.ivPreview);
            ivPreview.setImageBitmap(selectedImage);}
            catch(IOException e )
            {
                Toast.makeText(getActivity(),"Could not Load Image",Toast.LENGTH_LONG).show();
            }

        }
    }

}
